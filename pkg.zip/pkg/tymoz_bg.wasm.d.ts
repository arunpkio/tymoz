/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function main(): void;
export function slint_mock_elapsed_time(a: number): void;
export function slint_get_mocked_time(): number;
export function slint_send_mouse_click(a: number, b: number, c: number): void;
export function slint_send_keyboard_char(a: number, b: number, c: number): void;
export function send_keyboard_string_sequence(a: number, b: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h2253e8007a5e5edc(a: number, b: number, c: number): void;
export function _dyn_core__ops__function__FnMut__A_B___Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h571409af2633e2e4(a: number, b: number, c: number, d: number): void;
export function _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h21070738c8e31518(a: number, b: number): void;
export function _dyn_core__ops__function__Fn__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h3133cab64c99989e(a: number, b: number, c: number): void;
export function _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hd74be157539cc4d0(a: number, b: number): void;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h14ad1df19c0f6435(a: number, b: number, c: number): void;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h6ac4e95b554e6f20(a: number, b: number, c: number): void;
export function __wbindgen_exn_store(a: number): void;
export function __wbindgen_start(): void;
