# tymoz

A simple a Rust + SlintUI application to show time from different cities across different time zones.
